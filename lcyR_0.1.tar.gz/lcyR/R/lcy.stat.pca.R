lcy.stat.pca <- function(){

}
